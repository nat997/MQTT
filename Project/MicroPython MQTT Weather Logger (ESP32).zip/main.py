import network
import time
from machine import Pin
import dht
import ujson
from umqtt.simple import MQTTClient
from machine import Pin, PWM

# MQTT Server Parameters
MQTT_CLIENT_ID = "micropython-weather-demo"
MQTT_BROKER = "broker.mqttdashboard.com"
MQTT_USER = ""
MQTT_PASSWORD = ""
MQTT_TOPIC = "sensor_data/sensor_id_1"

# DHT22 Sensor
sensor = dht.DHT22(Pin(15))

# Stepper Motor Pins
step_pin = Pin(12, Pin.OUT)
dir_pin = Pin(13, Pin.OUT)
pwm = PWM(step_pin)

# Connect to WiFi
print("Connecting to WiFi", end="")
sta_if = network.WLAN(network.STA_IF)
sta_if.active(True)
sta_if.connect('Wokwi-GUEST', '')
while not sta_if.isconnected():
    print(".", end="")
    time.sleep(0.1)
print(" Connected!")

# Connect to MQTT Broker
print("Connecting to MQTT server... ", end="")
client = MQTTClient(MQTT_CLIENT_ID, MQTT_BROKER, user=MQTT_USER, password=MQTT_PASSWORD)
client.connect()

print("Connected!")

prev_weather = ""
while True:
    print("Measuring weather conditions... ", end="")
    sensor.measure()
    temperature = sensor.temperature()
    humidity = sensor.humidity()
    message = ujson.dumps({
        "sensor_id": "sensor_id_1",
        "location": "field_1",
        "temp": temperature,
        "humidity": humidity,
    })

    if message != prev_weather:
        print("Updated!")
        print("Reporting to MQTT topic {}: {}".format(MQTT_TOPIC, message))
        client.publish(MQTT_TOPIC, message)
        prev_weather = message
    else:
        print("No change")

    # Check humidity and activate stepper motor if below threshold
    if humidity < 45:
        print("Humidity too low! Activating stepper motor.")
        dir_pin.value(1)  # Set direction
        for _ in range(400):  # 400 steps for one full revolution (depends on your stepper motor configuration)
            pwm.duty(512)  # Set PWM duty cycle
            time.sleep_us(1000)  # Adjust based on your stepper motor speed requirement
            pwm.duty(0)  # Turn off PWM
            time.sleep_us(1000)

    time.sleep(1)
